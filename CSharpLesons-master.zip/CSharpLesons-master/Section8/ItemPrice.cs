﻿namespace Section8
{
    class ItemPrice
    {
        public ItemPrice(decimal price)
        {
            WholesalePrice = price;
        }

        public decimal WholesalePrice
        {
            get;
            set;
        }



    }
}
