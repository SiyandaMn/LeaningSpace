﻿using System;

namespace Section14.Final_Exam_1
{
    public class Element
    {
        public void Click()
        {
            Console.WriteLine("Click");
        }
    }
}