﻿using System;


namespace section15
{
    public class SectionOfRandomStuff
    {
        public void FillForm()
        {
            //I fill out the form
            Console.WriteLine("Fill out form");
        }
    }
}