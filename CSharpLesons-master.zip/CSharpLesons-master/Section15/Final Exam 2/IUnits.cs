﻿namespace Section14.Final_Exam_2
{
    interface IUnits
    {
        int GetNumUnits();
    }
}
