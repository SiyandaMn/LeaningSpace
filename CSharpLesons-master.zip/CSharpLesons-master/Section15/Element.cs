﻿using System;

namespace section15
{
    public class Element
    {
        public void Click()
        {
            Console.WriteLine("Click");
        }
    }
}