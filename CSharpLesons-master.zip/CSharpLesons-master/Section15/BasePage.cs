﻿namespace section15
{
    public abstract class BasePage
    {
        public abstract string PageName { get; }
    }
}