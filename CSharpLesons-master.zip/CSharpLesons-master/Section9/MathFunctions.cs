﻿using System;

namespace Section9
{
    class MathFunctions
    {
        public static double SquareRoot(double number)
        {
            return Math.Sqrt(number);
        }

        public static int Sum(int number1, int number2)
        {
            return number1 + number2;
        }

        public static double Sum(double number1, double number2)
        {
            return number1 + number2;
        }

        public static decimal Sum(decimal number1, decimal number2)
        {
            return number1 + number2;
        }
    }
}
