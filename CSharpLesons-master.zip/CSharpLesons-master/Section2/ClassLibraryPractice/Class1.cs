﻿namespace ClassLibraryPractice
{
    public static class Class1
    {
        public static int Addition(int number1, int number2)
        {
            return number1 + number2;
        }
    }
}
