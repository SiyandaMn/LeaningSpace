﻿namespace section14
{
    public class Animal {};

    public class Mammal : Animal { };

    public class Cat : Mammal { };
}
