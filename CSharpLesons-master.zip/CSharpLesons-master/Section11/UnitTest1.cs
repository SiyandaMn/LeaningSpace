﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Section11
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
