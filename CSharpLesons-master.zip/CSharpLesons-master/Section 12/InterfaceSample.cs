﻿namespace Section12
{
    class InterfaceSample //: IWebElement, IMouse
    {

    }
}
